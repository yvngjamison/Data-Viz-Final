
// placeholder for future interactivity
document.addEventListener('DOMContentLoaded',()=>console.log('Renewables at Work v2 loaded'));
